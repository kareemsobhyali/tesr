package com.flutter_template.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
