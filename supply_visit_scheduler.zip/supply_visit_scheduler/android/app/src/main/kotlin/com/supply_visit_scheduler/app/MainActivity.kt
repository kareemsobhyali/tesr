package com.supply_visit_scheduler.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
