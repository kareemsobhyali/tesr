import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/edit_appointment_form_widget.dart';

class EditAppointmentScreen extends StatefulWidget {
  final Map<String, dynamic>? appointmentData;

  const EditAppointmentScreen({super.key, this.appointmentData});

  @override
  State<EditAppointmentScreen> createState() => _EditAppointmentScreenState();
}

class _EditAppointmentScreenState extends State<EditAppointmentScreen> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _representativeController =
      TextEditingController();
  final TextEditingController _notesController = TextEditingController();

  String _selectedGoodsType = 'Electronics';
  DateTime _selectedDate = DateTime.now();
  TimeOfDay _selectedTime = TimeOfDay.now();
  bool _isLoading = false;
  bool _hasChanges = false;

  final List<String> _goodsTypes = [
    'Electronics',
    'Clothing',
    'Food & Beverages',
    'Medical Supplies',
    'Office Supplies',
    'Industrial Equipment',
    'Raw Materials',
    'Automotive Parts'
  ];

  @override
  void initState() {
    super.initState();
    _initializeFormData();
  }

  void _initializeFormData() {
    if (widget.appointmentData != null) {
      _representativeController.text =
          widget.appointmentData!['representativeName'] ?? '';
      _selectedGoodsType =
          widget.appointmentData!['goodsType'] ?? 'Electronics';
      _selectedDate = DateTime.parse(
          widget.appointmentData!['date'] ?? DateTime.now().toIso8601String());
      _selectedTime = TimeOfDay(
        hour: int.parse(widget.appointmentData!['time']?.split(':')[0] ?? '9'),
        minute:
            int.parse(widget.appointmentData!['time']?.split(':')[1] ?? '0'),
      );
      _notesController.text = widget.appointmentData!['notes'] ?? '';
    }

    _representativeController.addListener(_onFormChanged);
    _notesController.addListener(_onFormChanged);
  }

  void _onFormChanged() {
    if (!_hasChanges) {
      setState(() {
        _hasChanges = true;
      });
    }
  }

  @override
  void dispose() {
    _representativeController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  Future<void> _updateAppointment() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() {
      _isLoading = true;
    });

    try {
      // Simulate API call delay
      await Future.delayed(const Duration(seconds: 2));

      // Here you would typically update the appointment in your database
      // and reschedule notifications

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'تم تحديث الموعد بنجاح',
              style:
                  TextStyle(color: AppTheme.lightTheme.colorScheme.onSurface),
            ),
            backgroundColor: AppTheme.lightTheme.colorScheme.secondary,
          ),
        );
        Navigator.pop(context, true);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'فشل في تحديث الموعد',
              style: TextStyle(color: AppTheme.lightTheme.colorScheme.onError),
            ),
            backgroundColor: AppTheme.lightTheme.colorScheme.error,
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  Future<void> _deleteAppointment() async {
    final bool? confirmed = await showDialog<bool>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(
            'حذف الموعد',
            style: AppTheme.lightTheme.textTheme.titleLarge,
          ),
          content: Text(
            'هل أنت متأكد من حذف هذا الموعد؟ لا يمكن التراجع عن هذا الإجراء.',
            style: AppTheme.lightTheme.textTheme.bodyMedium,
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: Text(
                'إلغاء',
                style:
                    TextStyle(color: AppTheme.lightTheme.colorScheme.primary),
              ),
            ),
            TextButton(
              onPressed: () => Navigator.of(context).pop(true),
              style: TextButton.styleFrom(
                foregroundColor: AppTheme.lightTheme.colorScheme.error,
              ),
              child: const Text('حذف'),
            ),
          ],
        );
      },
    );

    if (confirmed == true) {
      setState(() {
        _isLoading = true;
      });

      try {
        // Simulate API call delay
        await Future.delayed(const Duration(seconds: 1));

        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(
                'تم حذف الموعد بنجاح',
                style:
                    TextStyle(color: AppTheme.lightTheme.colorScheme.onSurface),
              ),
              backgroundColor: AppTheme.lightTheme.colorScheme.secondary,
            ),
          );
          Navigator.pop(context, true);
        }
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(
                'فشل في حذف الموعد',
                style:
                    TextStyle(color: AppTheme.lightTheme.colorScheme.onError),
              ),
              backgroundColor: AppTheme.lightTheme.colorScheme.error,
            ),
          );
        }
      } finally {
        if (mounted) {
          setState(() {
            _isLoading = false;
          });
        }
      }
    }
  }

  Future<bool> _onWillPop() async {
    if (!_hasChanges) return true;

    final bool? shouldPop = await showDialog<bool>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(
            'تغييرات غير محفوظة',
            style: AppTheme.lightTheme.textTheme.titleLarge,
          ),
          content: Text(
            'لديك تغييرات غير محفوظة. هل تريد المغادرة بدون حفظ؟',
            style: AppTheme.lightTheme.textTheme.bodyMedium,
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: Text(
                'البقاء',
                style:
                    TextStyle(color: AppTheme.lightTheme.colorScheme.primary),
              ),
            ),
            TextButton(
              onPressed: () => Navigator.of(context).pop(true),
              style: TextButton.styleFrom(
                foregroundColor: AppTheme.lightTheme.colorScheme.error,
              ),
              child: const Text('المغادرة'),
            ),
          ],
        );
      },
    );

    return shouldPop ?? false;
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: WillPopScope(
        onWillPop: _onWillPop,
        child: Scaffold(
          backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
          appBar: AppBar(
            backgroundColor: AppTheme.lightTheme.colorScheme.surface,
            elevation: 1,
            leading: IconButton(
              onPressed: () async {
                if (await _onWillPop()) {
                  Navigator.pop(context);
                }
              },
              icon: CustomIconWidget(
                iconName: 'close',
                color: AppTheme.lightTheme.colorScheme.onSurface,
                size: 24,
              ),
            ),
            title: Text(
              'تعديل الموعد',
              style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                color: AppTheme.lightTheme.colorScheme.onSurface,
                fontWeight: FontWeight.w600,
              ),
            ),
            centerTitle: true,
            actions: [
              Padding(
                padding: EdgeInsets.only(left: 4.w),
                child: TextButton(
                  onPressed: _isLoading ? null : _updateAppointment,
                  child: _isLoading
                      ? SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            valueColor: AlwaysStoppedAnimation<Color>(
                              AppTheme.lightTheme.colorScheme.primary,
                            ),
                          ),
                        )
                      : Text(
                          'تحديث',
                          style: TextStyle(
                            color: AppTheme.lightTheme.colorScheme.primary,
                            fontWeight: FontWeight.w600,
                            fontSize: 14.sp,
                          ),
                        ),
                ),
              ),
            ],
          ),
          body: SafeArea(
            child: SingleChildScrollView(
              padding: EdgeInsets.all(4.w),
              child: EditAppointmentFormWidget(
                formKey: _formKey,
                representativeController: _representativeController,
                notesController: _notesController,
                selectedGoodsType: _selectedGoodsType,
                selectedDate: _selectedDate,
                selectedTime: _selectedTime,
                goodsTypes: _goodsTypes,
                isLoading: _isLoading,
                onGoodsTypeChanged: (value) {
                  setState(() {
                    _selectedGoodsType = value;
                    _hasChanges = true;
                  });
                },
                onDateChanged: (date) {
                  setState(() {
                    _selectedDate = date;
                    _hasChanges = true;
                  });
                },
                onTimeChanged: (time) {
                  setState(() {
                    _selectedTime = time;
                    _hasChanges = true;
                  });
                },
                onDeletePressed: _deleteAppointment,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
