import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/action_buttons_widget.dart';
import './widgets/appointment_info_card_widget.dart';
import './widgets/date_time_card_widget.dart';
import './widgets/goods_type_card_widget.dart';
import './widgets/notes_card_widget.dart';
import './widgets/representative_card_widget.dart';

class AppointmentDetailScreen extends StatefulWidget {
  const AppointmentDetailScreen({super.key});

  @override
  State<AppointmentDetailScreen> createState() =>
      _AppointmentDetailScreenState();
}

class _AppointmentDetailScreenState extends State<AppointmentDetailScreen> {
  // Mock appointment data
  final Map<String, dynamic> appointmentData = {
    "id": 1,
    "representativeName": "أحمد محمد الخليل",
    "representativePhone": "+966501234567",
    "representativeEmail": "ahmed.khalil@supplies.com",
    "goodsType": "مواد غذائية",
    "goodsCategory": "food_bank",
    "goodsDescription": "مواد غذائية أساسية ومعلبات",
    "appointmentDate": DateTime.now().add(Duration(days: 2)),
    "appointmentTime": "10:30 AM",
    "notes": "يرجى التأكد من توفر مساحة تخزين كافية في المستودع",
    "status": "مجدولة",
    "contactHistory": 3,
    "notificationEnabled": true,
    "createdDate": DateTime.now().subtract(Duration(days: 5)),
  };

  String _getRelativeTimeString(DateTime appointmentDate) {
    final now = DateTime.now();
    final difference = appointmentDate.difference(now).inDays;

    if (difference == 0) {
      return "اليوم";
    } else if (difference == 1) {
      return "غداً";
    } else if (difference == 2) {
      return "بعد غد";
    } else if (difference > 0) {
      return "خلال $difference أيام";
    } else {
      return "منتهية";
    }
  }

  void _showDeleteConfirmation() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: AlertDialog(
            title: Text(
              'حذف الموعد',
              style: AppTheme.lightTheme.textTheme.titleLarge,
            ),
            content: Text(
              'هل أنت متأكد من حذف هذا الموعد؟ لا يمكن التراجع عن هذا الإجراء.',
              style: AppTheme.lightTheme.textTheme.bodyMedium,
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: Text('إلغاء'),
              ),
              ElevatedButton(
                onPressed: () {
                  Navigator.of(context).pop();
                  Navigator.of(context).pop();
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('تم حذف الموعد بنجاح'),
                      backgroundColor: AppTheme.lightTheme.colorScheme.error,
                    ),
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppTheme.lightTheme.colorScheme.error,
                ),
                child: Text('حذف'),
              ),
            ],
          ),
        );
      },
    );
  }

  void _editAppointment() {
    Navigator.pushNamed(context, '/edit-appointment-screen');
  }

  void _duplicateAppointment() {
    Navigator.pushNamed(context, '/add-appointment-screen');
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('تم نسخ بيانات الموعد للإضافة الجديدة'),
        backgroundColor: AppTheme.lightTheme.colorScheme.secondary,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
        appBar: AppBar(
          backgroundColor: AppTheme.lightTheme.colorScheme.primary,
          foregroundColor: AppTheme.lightTheme.colorScheme.onPrimary,
          elevation: 2,
          title: Text(
            _getRelativeTimeString(
                appointmentData["appointmentDate"] as DateTime),
            style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
              color: AppTheme.lightTheme.colorScheme.onPrimary,
              fontWeight: FontWeight.w600,
            ),
          ),
          leading: IconButton(
            onPressed: () => Navigator.pop(context),
            icon: CustomIconWidget(
              iconName: 'arrow_back',
              color: AppTheme.lightTheme.colorScheme.onPrimary,
              size: 24,
            ),
          ),
          actions: [
            IconButton(
              onPressed: _editAppointment,
              icon: CustomIconWidget(
                iconName: 'edit',
                color: AppTheme.lightTheme.colorScheme.onPrimary,
                size: 24,
              ),
            ),
            SizedBox(width: 2.w),
          ],
        ),
        body: SafeArea(
          child: SingleChildScrollView(
            padding: EdgeInsets.all(4.w),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // Appointment Status Info
                AppointmentInfoCardWidget(
                  status: appointmentData["status"] as String,
                  createdDate: appointmentData["createdDate"] as DateTime,
                  notificationEnabled:
                      appointmentData["notificationEnabled"] as bool,
                ),

                SizedBox(height: 4.w),

                // Representative Information
                RepresentativeCardWidget(
                  name: appointmentData["representativeName"] as String,
                  phone: appointmentData["representativePhone"] as String,
                  email: appointmentData["representativeEmail"] as String,
                  contactHistory: appointmentData["contactHistory"] as int,
                ),

                SizedBox(height: 4.w),

                // Goods Type Information
                GoodsTypeCardWidget(
                  goodsType: appointmentData["goodsType"] as String,
                  category: appointmentData["goodsCategory"] as String,
                  description: appointmentData["goodsDescription"] as String,
                ),

                SizedBox(height: 4.w),

                // Date and Time Information
                DateTimeCardWidget(
                  appointmentDate:
                      appointmentData["appointmentDate"] as DateTime,
                  appointmentTime: appointmentData["appointmentTime"] as String,
                  relativeTime: _getRelativeTimeString(
                      appointmentData["appointmentDate"] as DateTime),
                ),

                SizedBox(height: 4.w),

                // Notes Section
                appointmentData["notes"] != null &&
                        (appointmentData["notes"] as String).isNotEmpty
                    ? NotesCardWidget(notes: appointmentData["notes"] as String)
                    : SizedBox.shrink(),

                appointmentData["notes"] != null &&
                        (appointmentData["notes"] as String).isNotEmpty
                    ? SizedBox(height: 4.w)
                    : SizedBox.shrink(),

                // Action Buttons
                ActionButtonsWidget(
                  onEdit: _editAppointment,
                  onDelete: _showDeleteConfirmation,
                  onDuplicate: _duplicateAppointment,
                ),

                SizedBox(height: 8.w),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
