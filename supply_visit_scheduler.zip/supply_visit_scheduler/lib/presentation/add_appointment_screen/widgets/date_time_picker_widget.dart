import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class DateTimePickerWidget extends StatelessWidget {
  final DateTime? selectedDate;
  final TimeOfDay? selectedTime;
  final Function(DateTime) onDateSelected;
  final Function(TimeOfDay) onTimeSelected;

  const DateTimePickerWidget({
    super.key,
    required this.selectedDate,
    required this.selectedTime,
    required this.onDateSelected,
    required this.onTimeSelected,
  });

  Future<void> _selectDate(BuildContext context) async {
    final DateTime now = DateTime.now();
    final DateTime firstDate = now;
    final DateTime lastDate = DateTime(now.year + 2);

    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: selectedDate ?? now.add(Duration(days: 1)),
      firstDate: firstDate,
      lastDate: lastDate,
      locale: const Locale('ar', 'SA'),
      builder: (context, child) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: Theme(
            data: Theme.of(context).copyWith(
              datePickerTheme: DatePickerThemeData(
                backgroundColor: AppTheme.lightTheme.colorScheme.surface,
                headerBackgroundColor: AppTheme.lightTheme.colorScheme.primary,
                headerForegroundColor:
                    AppTheme.lightTheme.colorScheme.onPrimary,
                dayForegroundColor: WidgetStateProperty.resolveWith((states) {
                  if (states.contains(WidgetState.selected)) {
                    return AppTheme.lightTheme.colorScheme.onPrimary;
                  }
                  return AppTheme.lightTheme.colorScheme.onSurface;
                }),
                dayBackgroundColor: WidgetStateProperty.resolveWith((states) {
                  if (states.contains(WidgetState.selected)) {
                    return AppTheme.lightTheme.colorScheme.primary;
                  }
                  return null;
                }),
                todayForegroundColor: WidgetStateProperty.all(
                  AppTheme.lightTheme.colorScheme.primary,
                ),
                todayBackgroundColor: WidgetStateProperty.all(
                  AppTheme.lightTheme.colorScheme.primary
                      .withValues(alpha: 0.1),
                ),
              ),
            ),
            child: child!,
          ),
        );
      },
    );

    if (picked != null) {
      // Validate business day (Sunday to Thursday in Saudi Arabia)
      if (picked.weekday == DateTime.friday ||
          picked.weekday == DateTime.saturday) {
        _showBusinessDayWarning(context);
        return;
      }
      onDateSelected(picked);
    }
  }

  Future<void> _selectTime(BuildContext context) async {
    final TimeOfDay now = TimeOfDay.now();
    final TimeOfDay initialTime = selectedTime ?? TimeOfDay(hour: 9, minute: 0);

    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: initialTime,
      builder: (context, child) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: MediaQuery(
            data: MediaQuery.of(context).copyWith(
              alwaysUse24HourFormat: false,
            ),
            child: child!,
          ),
        );
      },
    );

    if (picked != null) {
      // Validate business hours (8 AM to 6 PM)
      if (picked.hour < 8 || picked.hour > 18) {
        _showBusinessHoursWarning(context);
        return;
      }
      onTimeSelected(picked);
    }
  }

  void _showBusinessDayWarning(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          title: Text(
            "تنبيه",
            style: AppTheme.lightTheme.textTheme.titleLarge,
          ),
          content: Text(
            "يُفضل اختيار موعد في أيام العمل (الأحد - الخميس)",
            style: AppTheme.lightTheme.textTheme.bodyMedium,
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text(
                "موافق",
                style:
                    TextStyle(color: AppTheme.lightTheme.colorScheme.primary),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showBusinessHoursWarning(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          title: Text(
            "تنبيه",
            style: AppTheme.lightTheme.textTheme.titleLarge,
          ),
          content: Text(
            "يُفضل اختيار موعد في ساعات العمل (8:00 ص - 6:00 م)",
            style: AppTheme.lightTheme.textTheme.bodyMedium,
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text(
                "موافق",
                style:
                    TextStyle(color: AppTheme.lightTheme.colorScheme.primary),
              ),
            ),
          ],
        ),
      ),
    );
  }

  String _formatDate(DateTime date) {
    final List<String> arabicMonths = [
      'يناير',
      'فبراير',
      'مارس',
      'أبريل',
      'مايو',
      'يونيو',
      'يوليو',
      'أغسطس',
      'سبتمبر',
      'أكتوبر',
      'نوفمبر',
      'ديسمبر'
    ];

    final List<String> arabicDays = [
      'الاثنين',
      'الثلاثاء',
      'الأربعاء',
      'الخميس',
      'الجمعة',
      'السبت',
      'الأحد'
    ];

    final dayName = arabicDays[date.weekday - 1];
    final monthName = arabicMonths[date.month - 1];

    return '$dayName، ${date.day} $monthName ${date.year}';
  }

  String _formatTime(TimeOfDay time) {
    final hour = time.hourOfPeriod == 0 ? 12 : time.hourOfPeriod;
    final minute = time.minute.toString().padLeft(2, '0');
    final period = time.period == DayPeriod.am ? 'ص' : 'م';

    return '$hour:$minute $period';
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Date Picker
        GestureDetector(
          onTap: () => _selectDate(context),
          child: Container(
            width: double.infinity,
            padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.inputDecorationTheme.fillColor,
              border: Border.all(
                color: selectedDate != null
                    ? AppTheme.lightTheme.colorScheme.primary
                    : AppTheme.lightTheme.dividerColor.withValues(alpha: 0.5),
                width: 1,
              ),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Row(
              children: [
                CustomIconWidget(
                  iconName: 'calendar_today',
                  color: selectedDate != null
                      ? AppTheme.lightTheme.colorScheme.primary
                      : AppTheme.lightTheme.colorScheme.onSurface
                          .withValues(alpha: 0.6),
                  size: 20,
                ),
                SizedBox(width: 3.w),
                Expanded(
                  child: Text(
                    selectedDate != null
                        ? _formatDate(selectedDate!)
                        : "اختر التاريخ",
                    style: AppTheme.lightTheme.textTheme.bodyLarge?.copyWith(
                      color: selectedDate != null
                          ? AppTheme.lightTheme.colorScheme.onSurface
                          : AppTheme
                              .lightTheme.inputDecorationTheme.hintStyle?.color,
                    ),
                    textDirection: TextDirection.rtl,
                  ),
                ),
              ],
            ),
          ),
        ),

        SizedBox(height: 2.h),

        // Time Picker
        GestureDetector(
          onTap: () => _selectTime(context),
          child: Container(
            width: double.infinity,
            padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.inputDecorationTheme.fillColor,
              border: Border.all(
                color: selectedTime != null
                    ? AppTheme.lightTheme.colorScheme.primary
                    : AppTheme.lightTheme.dividerColor.withValues(alpha: 0.5),
                width: 1,
              ),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Row(
              children: [
                CustomIconWidget(
                  iconName: 'access_time',
                  color: selectedTime != null
                      ? AppTheme.lightTheme.colorScheme.primary
                      : AppTheme.lightTheme.colorScheme.onSurface
                          .withValues(alpha: 0.6),
                  size: 20,
                ),
                SizedBox(width: 3.w),
                Expanded(
                  child: Text(
                    selectedTime != null
                        ? _formatTime(selectedTime!)
                        : "اختر الوقت",
                    style: AppTheme.lightTheme.textTheme.bodyLarge?.copyWith(
                      color: selectedTime != null
                          ? AppTheme.lightTheme.colorScheme.onSurface
                          : AppTheme
                              .lightTheme.inputDecorationTheme.hintStyle?.color,
                    ),
                    textDirection: TextDirection.rtl,
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
