import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class GoodsTypeSelectorWidget extends StatelessWidget {
  final List<Map<String, dynamic>> goodsTypes;
  final String? selectedType;
  final Function(String) onTypeSelected;

  const GoodsTypeSelectorWidget({
    super.key,
    required this.goodsTypes,
    required this.selectedType,
    required this.onTypeSelected,
  });

  void _showGoodsTypeBottomSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => Directionality(
        textDirection: TextDirection.rtl,
        child: Container(
          height: 60.h,
          decoration: BoxDecoration(
            color: AppTheme.lightTheme.colorScheme.surface,
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(20),
              topRight: Radius.circular(20),
            ),
          ),
          child: Column(
            children: [
              // Handle bar
              Container(
                width: 12.w,
                height: 0.5.h,
                margin: EdgeInsets.symmetric(vertical: 2.h),
                decoration: BoxDecoration(
                  color: AppTheme.lightTheme.colorScheme.onSurface
                      .withValues(alpha: 0.3),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),

              // Header
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "اختر نوع البضائع",
                      style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    IconButton(
                      onPressed: () => Navigator.pop(context),
                      icon: CustomIconWidget(
                        iconName: 'close',
                        color: AppTheme.lightTheme.colorScheme.onSurface,
                        size: 24,
                      ),
                    ),
                  ],
                ),
              ),

              Divider(
                color: AppTheme.lightTheme.dividerColor,
                height: 1,
              ),

              // Goods types list
              Expanded(
                child: ListView.separated(
                  padding: EdgeInsets.symmetric(vertical: 2.h),
                  itemCount: goodsTypes.length,
                  separatorBuilder: (context, index) => Divider(
                    height: 1,
                    color:
                        AppTheme.lightTheme.dividerColor.withValues(alpha: 0.5),
                    indent: 16.w,
                  ),
                  itemBuilder: (context, index) {
                    final goodsType = goodsTypes[index];
                    final isSelected = selectedType == goodsType["name"];

                    return ListTile(
                      contentPadding:
                          EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
                      leading: Container(
                        width: 12.w,
                        height: 12.w,
                        decoration: BoxDecoration(
                          color: isSelected
                              ? AppTheme.lightTheme.colorScheme.primary
                                  .withValues(alpha: 0.1)
                              : AppTheme.lightTheme.colorScheme.surface,
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(
                            color: isSelected
                                ? AppTheme.lightTheme.colorScheme.primary
                                : AppTheme.lightTheme.dividerColor,
                            width: 1.5,
                          ),
                        ),
                        child: Center(
                          child: CustomIconWidget(
                            iconName: goodsType["icon"] as String,
                            color: isSelected
                                ? AppTheme.lightTheme.colorScheme.primary
                                : AppTheme.lightTheme.colorScheme.onSurface
                                    .withValues(alpha: 0.6),
                            size: 24,
                          ),
                        ),
                      ),
                      title: Text(
                        goodsType["name"] as String,
                        style:
                            AppTheme.lightTheme.textTheme.bodyLarge?.copyWith(
                          fontWeight:
                              isSelected ? FontWeight.w600 : FontWeight.w400,
                          color: isSelected
                              ? AppTheme.lightTheme.colorScheme.primary
                              : AppTheme.lightTheme.colorScheme.onSurface,
                        ),
                      ),
                      trailing: isSelected
                          ? CustomIconWidget(
                              iconName: 'check_circle',
                              color: AppTheme.lightTheme.colorScheme.primary,
                              size: 24,
                            )
                          : null,
                      onTap: () {
                        onTypeSelected(goodsType["name"] as String);
                        Navigator.pop(context);
                      },
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => _showGoodsTypeBottomSheet(context),
      child: Container(
        width: double.infinity,
        padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
        decoration: BoxDecoration(
          color: AppTheme.lightTheme.inputDecorationTheme.fillColor,
          border: Border.all(
            color: selectedType != null
                ? AppTheme.lightTheme.colorScheme.primary
                : AppTheme.lightTheme.dividerColor.withValues(alpha: 0.5),
            width: 1,
          ),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Row(
          children: [
            CustomIconWidget(
              iconName: 'category',
              color: selectedType != null
                  ? AppTheme.lightTheme.colorScheme.primary
                  : AppTheme.lightTheme.colorScheme.onSurface
                      .withValues(alpha: 0.6),
              size: 20,
            ),
            SizedBox(width: 3.w),
            Expanded(
              child: Text(
                selectedType ?? "اختر نوع البضائع",
                style: AppTheme.lightTheme.textTheme.bodyLarge?.copyWith(
                  color: selectedType != null
                      ? AppTheme.lightTheme.colorScheme.onSurface
                      : AppTheme
                          .lightTheme.inputDecorationTheme.hintStyle?.color,
                ),
                textDirection: TextDirection.rtl,
              ),
            ),
            CustomIconWidget(
              iconName: 'keyboard_arrow_down',
              color: AppTheme.lightTheme.colorScheme.onSurface
                  .withValues(alpha: 0.6),
              size: 24,
            ),
          ],
        ),
      ),
    );
  }
}
