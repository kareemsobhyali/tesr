import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class RepresentativeNameFieldWidget extends StatefulWidget {
  final TextEditingController controller;
  final List<String> previousRepresentatives;
  final Function(String) onChanged;

  const RepresentativeNameFieldWidget({
    super.key,
    required this.controller,
    required this.previousRepresentatives,
    required this.onChanged,
  });

  @override
  State<RepresentativeNameFieldWidget> createState() =>
      _RepresentativeNameFieldWidgetState();
}

class _RepresentativeNameFieldWidgetState
    extends State<RepresentativeNameFieldWidget> {
  List<String> _filteredSuggestions = [];
  final bool _showSuggestions = false;
  final LayerLink _layerLink = LayerLink();
  OverlayEntry? _overlayEntry;

  @override
  void initState() {
    super.initState();
    widget.controller.addListener(_onTextChanged);
  }

  @override
  void dispose() {
    _removeOverlay();
    widget.controller.removeListener(_onTextChanged);
    super.dispose();
  }

  void _onTextChanged() {
    final text = widget.controller.text.trim();
    widget.onChanged(text);

    if (text.isNotEmpty) {
      _filteredSuggestions = widget.previousRepresentatives
          .where((name) => name.contains(text))
          .toList();

      if (_filteredSuggestions.isNotEmpty) {
        _showSuggestionsOverlay();
      } else {
        _removeOverlay();
      }
    } else {
      _removeOverlay();
    }
  }

  void _showSuggestionsOverlay() {
    _removeOverlay();

    _overlayEntry = OverlayEntry(
      builder: (context) => Positioned(
        width: 92.w,
        child: CompositedTransformFollower(
          link: _layerLink,
          showWhenUnlinked: false,
          offset: Offset(0, 7.h),
          child: Material(
            elevation: 4,
            borderRadius: BorderRadius.circular(8),
            color: AppTheme.lightTheme.colorScheme.surface,
            child: Container(
              constraints: BoxConstraints(maxHeight: 25.h),
              child: ListView.separated(
                shrinkWrap: true,
                padding: EdgeInsets.symmetric(vertical: 1.h),
                itemCount: _filteredSuggestions.length,
                separatorBuilder: (context, index) => Divider(
                  height: 1,
                  color: AppTheme.lightTheme.dividerColor,
                ),
                itemBuilder: (context, index) {
                  final suggestion = _filteredSuggestions[index];
                  return ListTile(
                    dense: true,
                    title: Text(
                      suggestion,
                      style: AppTheme.lightTheme.textTheme.bodyMedium,
                      textDirection: TextDirection.rtl,
                    ),
                    leading: CustomIconWidget(
                      iconName: 'person',
                      color: AppTheme.lightTheme.colorScheme.primary,
                      size: 20,
                    ),
                    onTap: () {
                      widget.controller.text = suggestion;
                      widget.onChanged(suggestion);
                      _removeOverlay();
                    },
                  );
                },
              ),
            ),
          ),
        ),
      ),
    );

    Overlay.of(context).insert(_overlayEntry!);
  }

  void _removeOverlay() {
    _overlayEntry?.remove();
    _overlayEntry = null;
  }

  @override
  Widget build(BuildContext context) {
    return CompositedTransformTarget(
      link: _layerLink,
      child: SizedBox(
        width: double.infinity,
        child: TextFormField(
          controller: widget.controller,
          textDirection: TextDirection.rtl,
          style: AppTheme.lightTheme.textTheme.bodyLarge,
          decoration: InputDecoration(
            hintText: "أدخل اسم المندوب",
            hintStyle: AppTheme.lightTheme.inputDecorationTheme.hintStyle,
            prefixIcon: Padding(
              padding: EdgeInsets.all(3.w),
              child: CustomIconWidget(
                iconName: 'person',
                color: AppTheme.lightTheme.colorScheme.onSurface
                    .withValues(alpha: 0.6),
                size: 20,
              ),
            ),
            suffixIcon: widget.controller.text.isNotEmpty
                ? IconButton(
                    onPressed: () {
                      widget.controller.clear();
                      widget.onChanged('');
                      _removeOverlay();
                    },
                    icon: CustomIconWidget(
                      iconName: 'clear',
                      color: AppTheme.lightTheme.colorScheme.onSurface
                          .withValues(alpha: 0.6),
                      size: 20,
                    ),
                  )
                : null,
            border: AppTheme.lightTheme.inputDecorationTheme.border,
            enabledBorder:
                AppTheme.lightTheme.inputDecorationTheme.enabledBorder,
            focusedBorder:
                AppTheme.lightTheme.inputDecorationTheme.focusedBorder,
            errorBorder: AppTheme.lightTheme.inputDecorationTheme.errorBorder,
            filled: true,
            fillColor: AppTheme.lightTheme.inputDecorationTheme.fillColor,
          ),
          validator: (value) {
            if (value == null || value.trim().isEmpty) {
              return "يرجى إدخال اسم المندوب";
            }
            if (value.trim().length < 2) {
              return "يجب أن يكون الاسم أكثر من حرفين";
            }
            return null;
          },
          onTap: () {
            if (widget.controller.text.isNotEmpty &&
                _filteredSuggestions.isNotEmpty) {
              _showSuggestionsOverlay();
            }
          },
          onFieldSubmitted: (value) {
            _removeOverlay();
          },
        ),
      ),
    );
  }
}
