import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class NotesFieldWidget extends StatelessWidget {
  final TextEditingController controller;

  const NotesFieldWidget({
    super.key,
    required this.controller,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      child: TextFormField(
        controller: controller,
        textDirection: TextDirection.rtl,
        style: AppTheme.lightTheme.textTheme.bodyLarge,
        maxLines: 4,
        minLines: 3,
        maxLength: 500,
        decoration: InputDecoration(
          hintText: "أضف ملاحظات إضافية حول الموعد (اختياري)",
          hintStyle: AppTheme.lightTheme.inputDecorationTheme.hintStyle,
          prefixIcon: Padding(
            padding: EdgeInsets.only(top: 3.w, right: 3.w),
            child: CustomIconWidget(
              iconName: 'note_add',
              color: AppTheme.lightTheme.colorScheme.onSurface
                  .withValues(alpha: 0.6),
              size: 20,
            ),
          ),
          suffixIcon: controller.text.isNotEmpty
              ? Padding(
                  padding: EdgeInsets.only(top: 3.w, left: 3.w),
                  child: IconButton(
                    onPressed: () => controller.clear(),
                    icon: CustomIconWidget(
                      iconName: 'clear',
                      color: AppTheme.lightTheme.colorScheme.onSurface
                          .withValues(alpha: 0.6),
                      size: 20,
                    ),
                  ),
                )
              : null,
          border: AppTheme.lightTheme.inputDecorationTheme.border,
          enabledBorder: AppTheme.lightTheme.inputDecorationTheme.enabledBorder,
          focusedBorder: AppTheme.lightTheme.inputDecorationTheme.focusedBorder,
          filled: true,
          fillColor: AppTheme.lightTheme.inputDecorationTheme.fillColor,
          contentPadding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
          counterStyle: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
            color: AppTheme.lightTheme.colorScheme.onSurface
                .withValues(alpha: 0.6),
          ),
          alignLabelWithHint: true,
        ),
        textInputAction: TextInputAction.done,
        keyboardType: TextInputType.multiline,
        buildCounter: (context,
            {required currentLength, required isFocused, maxLength}) {
          return Padding(
            padding: EdgeInsets.only(top: 1.h),
            child: Text(
              '$currentLength/${maxLength ?? 500}',
              style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                color: currentLength > (maxLength ?? 500) * 0.8
                    ? AppTheme.lightTheme.colorScheme.error
                    : AppTheme.lightTheme.colorScheme.onSurface
                        .withValues(alpha: 0.6),
              ),
              textDirection: TextDirection.ltr,
            ),
          );
        },
      ),
    );
  }
}
