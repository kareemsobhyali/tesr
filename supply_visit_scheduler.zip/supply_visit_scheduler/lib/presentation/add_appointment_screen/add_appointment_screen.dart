import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/date_time_picker_widget.dart';
import './widgets/goods_type_selector_widget.dart';
import './widgets/notes_field_widget.dart';
import './widgets/representative_name_field_widget.dart';

class AddAppointmentScreen extends StatefulWidget {
  const AddAppointmentScreen({super.key});

  @override
  State<AddAppointmentScreen> createState() => _AddAppointmentScreenState();
}

class _AddAppointmentScreenState extends State<AddAppointmentScreen> {
  final _formKey = GlobalKey<FormState>();
  final _representativeNameController = TextEditingController();
  final _notesController = TextEditingController();

  String? _selectedGoodsType;
  DateTime? _selectedDate;
  TimeOfDay? _selectedTime;
  bool _isLoading = false;

  final List<Map<String, dynamic>> _goodsTypes = [
    {"id": 1, "name": "مواد غذائية", "icon": "restaurant"},
    {"id": 2, "name": "مواد تنظيف", "icon": "cleaning_services"},
    {"id": 3, "name": "أدوات مكتبية", "icon": "business_center"},
    {"id": 4, "name": "معدات طبية", "icon": "medical_services"},
    {"id": 5, "name": "مواد بناء", "icon": "construction"},
    {"id": 6, "name": "إلكترونيات", "icon": "devices"},
    {"id": 7, "name": "منسوجات", "icon": "checkroom"},
    {"id": 8, "name": "أخرى", "icon": "category"},
  ];

  final List<String> _previousRepresentatives = [
    "أحمد محمد علي",
    "فاطمة حسن الزهراني",
    "محمد عبدالله القحطاني",
    "نورا سعد العتيبي",
    "خالد يوسف الشهري",
  ];

  bool get _isFormValid {
    return _representativeNameController.text.trim().isNotEmpty &&
        _selectedGoodsType != null &&
        _selectedDate != null &&
        _selectedTime != null;
  }

  @override
  void dispose() {
    _representativeNameController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  Future<void> _saveAppointment() async {
    if (!_isFormValid) return;

    setState(() {
      _isLoading = true;
    });

    try {
      // Simulate database save operation
      await Future.delayed(const Duration(seconds: 2));

      // Check for duplicate appointments
      final appointmentDateTime = DateTime(
        _selectedDate!.year,
        _selectedDate!.month,
        _selectedDate!.day,
        _selectedTime!.hour,
        _selectedTime!.minute,
      );

      // Validate past date
      if (appointmentDateTime.isBefore(DateTime.now())) {
        _showErrorDialog("لا يمكن حجز موعد في الماضي");
        return;
      }

      // Show success message
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            "تم حفظ الموعد بنجاح",
            style: TextStyle(color: AppTheme.lightTheme.colorScheme.onSurface),
            textDirection: TextDirection.rtl,
          ),
          backgroundColor: AppTheme.lightTheme.colorScheme.primary,
          behavior: SnackBarBehavior.floating,
        ),
      );

      // Navigate back to appointment list
      Navigator.pushReplacementNamed(context, '/appointment-list-screen');
    } catch (e) {
      _showRetryDialog();
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (context) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          title: Text(
            "خطأ",
            style: AppTheme.lightTheme.textTheme.titleLarge,
          ),
          content: Text(
            message,
            style: AppTheme.lightTheme.textTheme.bodyMedium,
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text(
                "موافق",
                style:
                    TextStyle(color: AppTheme.lightTheme.colorScheme.primary),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showRetryDialog() {
    showDialog(
      context: context,
      builder: (context) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          title: Text(
            "فشل في الحفظ",
            style: AppTheme.lightTheme.textTheme.titleLarge,
          ),
          content: Text(
            "حدث خطأ أثناء حفظ الموعد. هل تريد المحاولة مرة أخرى؟",
            style: AppTheme.lightTheme.textTheme.bodyMedium,
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text(
                "إلغاء",
                style: TextStyle(color: AppTheme.lightTheme.colorScheme.error),
              ),
            ),
            TextButton(
              onPressed: () {
                Navigator.pop(context);
                _saveAppointment();
              },
              child: Text(
                "إعادة المحاولة",
                style:
                    TextStyle(color: AppTheme.lightTheme.colorScheme.primary),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
        appBar: AppBar(
          backgroundColor: AppTheme.lightTheme.colorScheme.surface,
          elevation: 1,
          leading: IconButton(
            onPressed: () => Navigator.pop(context),
            icon: CustomIconWidget(
              iconName: 'close',
              color: AppTheme.lightTheme.colorScheme.onSurface,
              size: 24,
            ),
          ),
          title: Text(
            "إضافة موعد جديد",
            style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          centerTitle: true,
          actions: [
            Padding(
              padding: EdgeInsets.only(left: 4.w),
              child: _isLoading
                  ? SizedBox(
                      width: 24,
                      height: 24,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        valueColor: AlwaysStoppedAnimation<Color>(
                          AppTheme.lightTheme.colorScheme.primary,
                        ),
                      ),
                    )
                  : TextButton(
                      onPressed: _isFormValid ? _saveAppointment : null,
                      style: TextButton.styleFrom(
                        foregroundColor: _isFormValid
                            ? AppTheme.lightTheme.colorScheme.primary
                            : AppTheme.lightTheme.colorScheme.onSurface
                                .withValues(alpha: 0.38),
                      ),
                      child: Text(
                        "حفظ",
                        style:
                            AppTheme.lightTheme.textTheme.labelLarge?.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
            ),
          ],
        ),
        body: SafeArea(
          child: Form(
            key: _formKey,
            child: SingleChildScrollView(
              padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Representative Name Section
                  _buildSectionHeader("اسم المندوب"),
                  SizedBox(height: 1.h),
                  RepresentativeNameFieldWidget(
                    controller: _representativeNameController,
                    previousRepresentatives: _previousRepresentatives,
                    onChanged: (value) => setState(() {}),
                  ),

                  SizedBox(height: 3.h),

                  // Goods Type Section
                  _buildSectionHeader("نوع البضائع"),
                  SizedBox(height: 1.h),
                  GoodsTypeSelectorWidget(
                    goodsTypes: _goodsTypes,
                    selectedType: _selectedGoodsType,
                    onTypeSelected: (type) {
                      setState(() {
                        _selectedGoodsType = type;
                      });
                    },
                  ),

                  SizedBox(height: 3.h),

                  // Date and Time Section
                  _buildSectionHeader("التاريخ والوقت"),
                  SizedBox(height: 1.h),
                  DateTimePickerWidget(
                    selectedDate: _selectedDate,
                    selectedTime: _selectedTime,
                    onDateSelected: (date) {
                      setState(() {
                        _selectedDate = date;
                      });
                    },
                    onTimeSelected: (time) {
                      setState(() {
                        _selectedTime = time;
                      });
                    },
                  ),

                  SizedBox(height: 3.h),

                  // Notes Section
                  _buildSectionHeader("ملاحظات (اختياري)"),
                  SizedBox(height: 1.h),
                  NotesFieldWidget(
                    controller: _notesController,
                  ),

                  SizedBox(height: 4.h),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Text(
      title,
      style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
        fontWeight: FontWeight.w600,
        color: AppTheme.lightTheme.colorScheme.onSurface,
      ),
    );
  }
}
