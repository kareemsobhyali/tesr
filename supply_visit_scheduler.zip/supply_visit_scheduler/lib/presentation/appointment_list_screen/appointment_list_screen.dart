import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/appointment_card_widget.dart';
import './widgets/empty_state_widget.dart';

class AppointmentListScreen extends StatefulWidget {
  const AppointmentListScreen({super.key});

  @override
  State<AppointmentListScreen> createState() => _AppointmentListScreenState();
}

class _AppointmentListScreenState extends State<AppointmentListScreen> {
  final TextEditingController _searchController = TextEditingController();
  List<Map<String, dynamic>> _filteredAppointments = [];
  bool _isSearching = false;

  // Mock data for appointments
  final List<Map<String, dynamic>> _appointments = [
    {
      "id": 1,
      "representativeName": "أحمد محمد علي",
      "goodsType": "مواد غذائية",
      "goodsIcon": "restaurant",
      "visitDate": DateTime.now().add(Duration(days: 1)),
      "status": "مجدولة",
      "isOverdue": false,
      "notes": "زيارة شهرية للمواد الغذائية الأساسية",
    },
    {
      "id": 2,
      "representativeName": "فاطمة حسن",
      "goodsType": "مواد تنظيف",
      "goodsIcon": "cleaning_services",
      "visitDate": DateTime.now().add(Duration(days: 3)),
      "status": "مؤكدة",
      "isOverdue": false,
      "notes": "توريد مواد التنظيف الصناعية",
    },
    {
      "id": 3,
      "representativeName": "محمد عبدالله",
      "goodsType": "قطع غيار",
      "goodsIcon": "build",
      "visitDate": DateTime.now().subtract(Duration(days: 1)),
      "status": "متأخرة",
      "isOverdue": true,
      "notes": "قطع غيار للمعدات الثقيلة",
    },
    {
      "id": 4,
      "representativeName": "سارة أحمد",
      "goodsType": "مكتبية",
      "goodsIcon": "business_center",
      "visitDate": DateTime.now().add(Duration(days: 7)),
      "status": "مجدولة",
      "isOverdue": false,
      "notes": "لوازم مكتبية وقرطاسية",
    },
    {
      "id": 5,
      "representativeName": "خالد محمود",
      "goodsType": "إلكترونيات",
      "goodsIcon": "electrical_services",
      "visitDate": DateTime.now().add(Duration(days: 14)),
      "status": "مؤكدة",
      "isOverdue": false,
      "notes": "معدات إلكترونية ومكونات",
    },
  ];

  @override
  void initState() {
    super.initState();
    _filteredAppointments = List.from(_appointments);
    _sortAppointmentsByDate();
  }

  void _sortAppointmentsByDate() {
    _filteredAppointments.sort((a, b) {
      DateTime dateA = a["visitDate"] as DateTime;
      DateTime dateB = b["visitDate"] as DateTime;
      return dateA.compareTo(dateB);
    });
  }

  void _filterAppointments(String query) {
    setState(() {
      if (query.isEmpty) {
        _filteredAppointments = List.from(_appointments);
      } else {
        _filteredAppointments = _appointments.where((appointment) {
          String repName =
              (appointment["representativeName"] as String).toLowerCase();
          String goodsType = (appointment["goodsType"] as String).toLowerCase();
          String searchQuery = query.toLowerCase();
          return repName.contains(searchQuery) ||
              goodsType.contains(searchQuery);
        }).toList();
      }
      _sortAppointmentsByDate();
    });
  }

  void _toggleSearch() {
    setState(() {
      _isSearching = !_isSearching;
      if (!_isSearching) {
        _searchController.clear();
        _filteredAppointments = List.from(_appointments);
        _sortAppointmentsByDate();
      }
    });
  }

  Future<void> _refreshAppointments() async {
    await Future.delayed(Duration(seconds: 1));
    setState(() {
      _sortAppointmentsByDate();
    });
  }

  void _showAppointmentOptions(
      BuildContext context, Map<String, dynamic> appointment) {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppTheme.lightTheme.colorScheme.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (context) => Container(
        padding: EdgeInsets.symmetric(vertical: 2.h, horizontal: 4.w),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 12.w,
              height: 0.5.h,
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.colorScheme.outline,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            SizedBox(height: 2.h),
            Text(
              appointment["representativeName"] as String,
              style: AppTheme.lightTheme.textTheme.titleMedium,
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 2.h),
            _buildOptionTile(
              context,
              icon: 'visibility',
              title: 'عرض التفاصيل',
              onTap: () {
                Navigator.pop(context);
                Navigator.pushNamed(
                  context,
                  '/appointment-detail-screen',
                  arguments: appointment,
                );
              },
            ),
            _buildOptionTile(
              context,
              icon: 'edit',
              title: 'تعديل الموعد',
              onTap: () {
                Navigator.pop(context);
                Navigator.pushNamed(
                  context,
                  '/edit-appointment-screen',
                  arguments: appointment,
                );
              },
            ),
            _buildOptionTile(
              context,
              icon: 'content_copy',
              title: 'نسخ الموعد',
              onTap: () {
                Navigator.pop(context);
                _duplicateAppointment(appointment);
              },
            ),
            _buildOptionTile(
              context,
              icon: 'delete',
              title: 'حذف الموعد',
              isDestructive: true,
              onTap: () {
                Navigator.pop(context);
                _showDeleteConfirmation(context, appointment);
              },
            ),
            SizedBox(height: 1.h),
          ],
        ),
      ),
    );
  }

  Widget _buildOptionTile(
    BuildContext context, {
    required String icon,
    required String title,
    required VoidCallback onTap,
    bool isDestructive = false,
  }) {
    return ListTile(
      leading: CustomIconWidget(
        iconName: icon,
        color: isDestructive
            ? AppTheme.lightTheme.colorScheme.error
            : AppTheme.lightTheme.colorScheme.primary,
        size: 24,
      ),
      title: Text(
        title,
        style: AppTheme.lightTheme.textTheme.bodyLarge?.copyWith(
          color: isDestructive
              ? AppTheme.lightTheme.colorScheme.error
              : AppTheme.lightTheme.colorScheme.onSurface,
        ),
      ),
      onTap: onTap,
    );
  }

  void _duplicateAppointment(Map<String, dynamic> appointment) {
    Map<String, dynamic> duplicatedAppointment = Map.from(appointment);
    duplicatedAppointment["id"] = _appointments.length + 1;
    duplicatedAppointment["visitDate"] =
        (appointment["visitDate"] as DateTime).add(Duration(days: 7));
    duplicatedAppointment["status"] = "مجدولة";
    duplicatedAppointment["isOverdue"] = false;

    setState(() {
      _appointments.add(duplicatedAppointment);
      _filteredAppointments = List.from(_appointments);
      _sortAppointmentsByDate();
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('تم نسخ الموعد بنجاح'),
        backgroundColor: AppTheme.lightTheme.colorScheme.primary,
      ),
    );
  }

  void _showDeleteConfirmation(
      BuildContext context, Map<String, dynamic> appointment) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: AppTheme.lightTheme.colorScheme.surface,
        title: Text(
          'تأكيد الحذف',
          style: AppTheme.lightTheme.textTheme.titleLarge,
        ),
        content: Text(
          'هل أنت متأكد من حذف موعد ${appointment["representativeName"]}؟',
          style: AppTheme.lightTheme.textTheme.bodyMedium,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('إلغاء'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              _deleteAppointment(appointment);
            },
            style: TextButton.styleFrom(
              foregroundColor: AppTheme.lightTheme.colorScheme.error,
            ),
            child: Text('حذف'),
          ),
        ],
      ),
    );
  }

  void _deleteAppointment(Map<String, dynamic> appointment) {
    setState(() {
      _appointments.removeWhere((item) => item["id"] == appointment["id"]);
      _filteredAppointments = List.from(_appointments);
      _sortAppointmentsByDate();
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('تم حذف الموعد بنجاح'),
        backgroundColor: AppTheme.lightTheme.colorScheme.error,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
        appBar: AppBar(
          backgroundColor: AppTheme.lightTheme.colorScheme.primary,
          foregroundColor: AppTheme.lightTheme.colorScheme.onPrimary,
          elevation: 2,
          title: _isSearching
              ? TextField(
                  controller: _searchController,
                  autofocus: true,
                  style: AppTheme.lightTheme.textTheme.bodyLarge?.copyWith(
                    color: AppTheme.lightTheme.colorScheme.onPrimary,
                  ),
                  decoration: InputDecoration(
                    hintText: 'البحث في المواعيد...',
                    hintStyle:
                        AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                      color: AppTheme.lightTheme.colorScheme.onPrimary
                          .withValues(alpha: 0.7),
                    ),
                    border: InputBorder.none,
                  ),
                  onChanged: _filterAppointments,
                )
              : Text(
                  'جدولة زيارات الموردين',
                  style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                    color: AppTheme.lightTheme.colorScheme.onPrimary,
                    fontWeight: FontWeight.bold,
                  ),
                ),
          actions: [
            IconButton(
              onPressed: _toggleSearch,
              icon: CustomIconWidget(
                iconName: _isSearching ? 'close' : 'search',
                color: AppTheme.lightTheme.colorScheme.onPrimary,
                size: 24,
              ),
            ),
            if (!_isSearching)
              IconButton(
                onPressed: () {
                  // Filter/Sort functionality
                },
                icon: CustomIconWidget(
                  iconName: 'filter_list',
                  color: AppTheme.lightTheme.colorScheme.onPrimary,
                  size: 24,
                ),
              ),
          ],
        ),
        body: SafeArea(
          child: _filteredAppointments.isEmpty
              ? EmptyStateWidget(
                  onAddPressed: () {
                    Navigator.pushNamed(context, '/add-appointment-screen');
                  },
                )
              : RefreshIndicator(
                  onRefresh: _refreshAppointments,
                  color: AppTheme.lightTheme.colorScheme.primary,
                  child: ListView.separated(
                    padding: EdgeInsets.all(4.w),
                    itemCount: _filteredAppointments.length,
                    separatorBuilder: (context, index) => SizedBox(height: 3.w),
                    itemBuilder: (context, index) {
                      final appointment = _filteredAppointments[index];
                      return AppointmentCardWidget(
                        appointment: appointment,
                        onTap: () {
                          Navigator.pushNamed(
                            context,
                            '/appointment-detail-screen',
                            arguments: appointment,
                          );
                        },
                        onLongPress: () {
                          _showAppointmentOptions(context, appointment);
                        },
                        onEdit: () {
                          Navigator.pushNamed(
                            context,
                            '/edit-appointment-screen',
                            arguments: appointment,
                          );
                        },
                        onDelete: () {
                          _showDeleteConfirmation(context, appointment);
                        },
                      );
                    },
                  ),
                ),
        ),
        floatingActionButton: FloatingActionButton(
          onPressed: () {
            Navigator.pushNamed(context, '/add-appointment-screen');
          },
          backgroundColor: AppTheme.lightTheme.colorScheme.secondary,
          foregroundColor: AppTheme.lightTheme.colorScheme.onSecondary,
          child: CustomIconWidget(
            iconName: 'add',
            color: AppTheme.lightTheme.colorScheme.onSecondary,
            size: 28,
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }
}
