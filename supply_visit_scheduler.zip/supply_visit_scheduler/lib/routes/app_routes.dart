import 'package:flutter/material.dart';
import '../presentation/appointment_list_screen/appointment_list_screen.dart';
import '../presentation/edit_appointment_screen/edit_appointment_screen.dart';
import '../presentation/add_appointment_screen/add_appointment_screen.dart';
import '../presentation/appointment_detail_screen/appointment_detail_screen.dart';

class AppRoutes {
  // TODO: Add your routes here
  static const String initial = '/';
  static const String appointmentListScreen = '/appointment-list-screen';
  static const String editAppointmentScreen = '/edit-appointment-screen';
  static const String addAppointmentScreen = '/add-appointment-screen';
  static const String appointmentDetailScreen = '/appointment-detail-screen';

  static Map<String, WidgetBuilder> routes = {
    initial: (context) => const AppointmentListScreen(),
    appointmentListScreen: (context) => const AppointmentListScreen(),
    editAppointmentScreen: (context) => const EditAppointmentScreen(),
    addAppointmentScreen: (context) => const AddAppointmentScreen(),
    appointmentDetailScreen: (context) => const AppointmentDetailScreen(),
    // TODO: Add your other routes here
  };
}
